# 🧠 Amygdala Protocol – Prometheus Edition (Public Release)

A mythic system guardian for Windows, designed to purge corruption, cleanse system clutter, and restore operational purity with clarity and confidence.

---

## ⚙️ Features

- 🔧 **System Integrity Sweep**  
  Runs `SFC` and `DISM` scans to detect and repair system file issues

- 🧹 **Cleanup Rituals**  
  Clears temporary folders and prefetch cache

- 🔁 **Windows Update Trigger**  
  Initiates updates silently for stability

- 📦 **App Upgrades via Winget**  
  Refreshes installed applications

- 🎮 **AMD GPU Driver Check**  
  Invokes Adrenalin upgrade prompt

- 📍 **System Restore Point**  
  Creates fallback snapshot named `Amygdala_PrePurge`

- 🧼 **Optional Deep Cleanup**  
  When run with `-DeepClean`, purges Recycle Bin and launches Disk Cleanup

---

## 🔧 Usage

Right-click the script → Run with **PowerShell (Admin)**  
Or schedule it via Task Scheduler:

```powershell
powershell.exe -ExecutionPolicy Bypass -File "Path\To\Amygdala_Public.ps1"