# ──◤ Amygdala Protocol: NVIDIA Edition ◢──
# System Sweep • Integrity Repair • Updates • NVIDIA Driver Maintenance

param(
    [switch]$DeepClean
)

Write-Host "`n🧠 Amygdala Protocol Engaged – NVIDIA Variant" -ForegroundColor Cyan

### 📍 Restore Point
Checkpoint-Computer -Description "Amygdala_PrePurge" -RestorePointType "MODIFY_SETTINGS"

### 🔧 Integrity Scan
sfc /scannow
DISM /Online /Cleanup-Image /RestoreHealth

### 🧹 Cleanup
Remove-Item "$env:TEMP\*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:USERPROFILE\AppData\Local\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
Get-ChildItem "$env:SystemRoot\Prefetch" -Filter *.pf | Remove-Item -Force -ErrorAction SilentlyContinue

### 🔁 Updates
Start-Process "cmd.exe" -ArgumentList "/c wuauclt /detectnow"
winget upgrade --all

### 🖥️ NVIDIA Driver Maintenance
Write-Host "`n🖥️ Checking NVIDIA GeForce Experience..." -ForegroundColor White
winget upgrade "NVIDIA GeForce Experience"

### 🧼 Deep Cleanup (optional)
if ($DeepClean) {
    Remove-Item "C:\$Recycle.Bin\*" -Recurse -Force -ErrorAction SilentlyContinue
    cleanmgr.exe /sagerun:1
}

### ✅ Summary
Write-Host "`n✅ Integrity Scan + Cleanup complete" -ForegroundColor Green
Write-Host "🖥️ NVIDIA Driver Status Checked" -ForegroundColor Green
Write-Host "📍 Restore Point: Created ('Amygdala_PrePurge')" -ForegroundColor Green
Write-Host "🕊️ Amygdala guards through particle and power." -ForegroundColor Magenta

exit