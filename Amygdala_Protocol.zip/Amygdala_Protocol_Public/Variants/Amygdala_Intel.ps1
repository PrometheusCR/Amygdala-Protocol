# ──◤ Amygdala Protocol: Intel Edition ◢──
# System Sweep • Integrity Repair • Updates • Intel Driver Support

param(
    [switch]$DeepClean
)

Write-Host "`n🧠 Amygdala Protocol Engaged – Intel Variant" -ForegroundColor Cyan

### 📍 Restore Point
Checkpoint-Computer -Description "Amygdala_PrePurge" -RestorePointType "MODIFY_SETTINGS"

### 🔧 Integrity Scan
sfc /scannow
DISM /Online /Cleanup-Image /RestoreHealth

### 🧹 Cleanup
Remove-Item "$env:TEMP\*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:USERPROFILE\AppData\Local\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
Get-ChildItem "$env:SystemRoot\Prefetch" -Filter *.pf | Remove-Item -Force -ErrorAction SilentlyContinue

### 🔁 Updates
Start-Process "cmd.exe" -ArgumentList "/c wuauclt /detectnow"
winget upgrade --all

### 🔬 Intel Driver Support Assistant
Write-Host "`n🔬 Checking Intel driver support tool..." -ForegroundColor White
winget upgrade "Intel® Driver & Support Assistant"

### 🧼 Deep Cleanup (optional)
if ($DeepClean) {
    Remove-Item "C:\$Recycle.Bin\*" -Recurse -Force -ErrorAction SilentlyContinue
    cleanmgr.exe /sagerun:1
}

### ✅ Summary
Write-Host "`n✅ Integrity Scan + Cleanup complete" -ForegroundColor Green
Write-Host "🔬 Intel Driver Support Checked" -ForegroundColor Green
Write-Host "📍 Restore Point: Created ('Amygdala_PrePurge')" -ForegroundColor Green
Write-Host "🕊️ All good. Amygdala whispers through the silicon." -ForegroundColor Magenta

exit