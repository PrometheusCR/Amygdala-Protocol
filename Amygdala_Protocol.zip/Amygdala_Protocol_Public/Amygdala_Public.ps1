# ──◤ Amygdala Protocol: Public Edition ◢──
# System Sweep • Integrity Repair • App Updates • Optional Deep Cleanup

param(
    [switch]$DeepClean
)

Write-Host "`n🧠 Amygdala Protocol Engaged – Public Guardian" -ForegroundColor Cyan

### 📍 0. Create Restore Point
Write-Host "`n📍 Creating restore point: 'Amygdala_PrePurge'" -ForegroundColor Magenta
Checkpoint-Computer -Description "Amygdala_PrePurge" -RestorePointType "MODIFY_SETTINGS"

### 🔧 1. Integrity Scan
Write-Host "`n🔧 Running SFC and DISM..." -ForegroundColor White
sfc /scannow
DISM /Online /Cleanup-Image /RestoreHealth

### 🧹 2. Basic System Cleanup
Write-Host "`n🧹 Clearing temp and prefetch folders..." -ForegroundColor White
Remove-Item "$env:TEMP\*" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:USERPROFILE\AppData\Local\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue

$prefetch = "$env:SystemRoot\Prefetch"
Get-ChildItem -Path $prefetch -Filter *.pf | Remove-Item -Force -ErrorAction SilentlyContinue

### 🔁 3. Trigger Windows Update
Write-Host "`n🔁 Initiating Windows Update scan..." -ForegroundColor White
Start-Process -FilePath "cmd.exe" -ArgumentList "/c wuauclt /detectnow"

### 📦 4. Upgrade Applications
Write-Host "`n📦 Upgrading apps via Winget..." -ForegroundColor White
winget upgrade --all

### 🖥️ 5. GPU Driver Check (AMD Recommended)
Write-Host "`n🎮 Checking AMD Adrenalin driver..." -ForegroundColor White
winget upgrade "AMD Software: Adrenalin Edition"

### 🧼 6. Deep Cleanup (Optional)
if ($DeepClean) {
    Write-Host "`n🧼 Running Deep Disk Echo Sweep..." -ForegroundColor Yellow
    Write-Host "🗑️ Emptying Recycle Bin..." -ForegroundColor Gray
    Remove-Item "C:\$Recycle.Bin\*" -Recurse -Force -ErrorAction SilentlyContinue

    Write-Host "📦 Executing cleanmgr sweep..." -ForegroundColor Gray
    cleanmgr.exe /sagerun:1
}

### ✅ 7. Summary & Exit
Write-Host "`n───────────── Sweep Summary ─────────────" -ForegroundColor White
Write-Host "🧠 Integrity Scan: SFC + DISM complete" -ForegroundColor Green
Write-Host "🧹 Cleanup: Temp + Prefetch cleared" -ForegroundColor Green
Write-Host "🔁 Updates: Windows + Winget triggered" -ForegroundColor Green
Write-Host "🎮 GPU: AMD driver check initiated" -ForegroundColor Green
if ($DeepClean) {
    Write-Host "🧼 Deep Clean: Recycle Bin + Disk Cleanup run" -ForegroundColor Green
}
Write-Host "📍 Restore Point: Amygdala_PrePurge created" -ForegroundColor Green
Write-Host "✅ Status: Stable and Purified" -ForegroundColor Cyan
Write-Host "🕊️ All good. Guardian ritual complete." -ForegroundColor Magenta
Write-Host "───────────────────────────────────────────" -ForegroundColor White

exit